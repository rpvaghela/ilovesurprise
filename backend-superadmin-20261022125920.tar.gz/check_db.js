require('dotenv').config();
const { PrismaClient } = require('./node_modules/@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const products = await prisma.products.findMany({
    select: {
      id: true,
      name: true,
      slug: true,
      scentNotes: true,
      ringSizes: true,
      jewelryTypes: true,
      surpriseType: true,
      product_variants: {
        select: {
          id: true,
          title: true,
          sku: true,
          price: true,
          stock: true,
          ringSize: true,
          scent: true,
          isActive: true
        }
      },
      product_options: {
        include: {
          product_option_values: true
        }
      }
    }
  });

  console.log('Total products:', products.length);
  for (const p of products) {
    console.log('-------------------------------------------');
    console.log(`Product: [${p.id}] ${p.name} (${p.slug})`);
    console.log(`ScentNotes:`, JSON.stringify(p.scentNotes));
    console.log(`RingSizes:`, JSON.stringify(p.ringSizes));
    console.log(`JewelryTypes:`, JSON.stringify(p.jewelryTypes));
    console.log(`SurpriseType:`, p.surpriseType);
    console.log(`Options:`, JSON.stringify(p.product_options));
    console.log(`Variants count: ${p.product_variants.length}`);
    if (p.product_variants.length > 0) {
      console.log(`Variants:`, JSON.stringify(p.product_variants, null, 2));
    }
  }
}

main()
  .catch(console.error)
  .finally(async () => {
    await prisma.$disconnect();
  });
